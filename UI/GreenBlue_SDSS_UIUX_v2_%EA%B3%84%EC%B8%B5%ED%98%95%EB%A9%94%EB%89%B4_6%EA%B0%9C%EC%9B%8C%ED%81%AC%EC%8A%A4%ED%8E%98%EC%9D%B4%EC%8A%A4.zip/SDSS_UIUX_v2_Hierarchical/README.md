# SDSS UI/UX v2.0 — 7 Global Menus / 6 GeoAI Workspaces

- `index.html`: 클릭 가능한 정적 화면 프로토타입. 브라우저에서 열어 전역·로컬·Workspace 메뉴를 이동해 볼 수 있음.
- `SDSS_메뉴_계층형_UX_설계명세_v2.0.md`: 정보구조, 클릭 동선, 모델별 UX, API 연계 범위.
- `screens/`: 브라우저 테스트로 캡처한 화면.

## 직접 확인할 UX 흐름

1. **Data Catalog** 선택 → 좌측에 `데이터 검색/품질/메타데이터/등록`이 보임 (Toolbox는 자동으로 열리지 않음).
2. 데이터 검색 화면에서 **선택 데이터로 분석 도구 찾기** → GeoAI Toolbox 6개 카드 허브.
3. **LCLUC 카드** 클릭 → LCLUC 입력 설정 Workspace.
4. **결과·통계/검증·근거/실행 이력** 탭 선택 → 전용 분석 단계 간 이동.
5. 좌측 **Climate Downscaling** 등 다른 모델 클릭 → 해당 특화 입력 화면. 외부 5개 모델은 실행 불가 상태 유지.

이 HTML은 UI 설계 시안이며, 실제 데이터나 운영 API에 연결되어 있지 않음.
